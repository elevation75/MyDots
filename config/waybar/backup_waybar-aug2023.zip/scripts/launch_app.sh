#!/bin/bash
/usr/bin/code
