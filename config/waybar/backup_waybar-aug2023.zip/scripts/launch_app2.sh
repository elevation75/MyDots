#!/bin/bash
/opt/sublime_text/sublime_text
